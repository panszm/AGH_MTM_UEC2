#!/bin/bash -e

export ROOT_DIR=$(pwd)
export PATH=tools:${PATH}
