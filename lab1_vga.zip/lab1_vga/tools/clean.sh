#!/bin/bash

# run from top directory

git clean -fdX
